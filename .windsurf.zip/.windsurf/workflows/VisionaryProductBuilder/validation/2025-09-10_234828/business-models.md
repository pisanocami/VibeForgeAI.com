# Business Models — Top 3 Moonshots

## SkillSwap
- Toma de fee 5‑12% por transacción aprobada.
- Suscripción Enterprise (compliance, SSO, auditoría, data residency) $2‑10k/mes.
- Evals premium / paquetes de datasets sintéticos por industria.
- Escrow/seguro de cumplimiento (rev‑share con aseguradora).

## AutoMatch
- SaaS por asiento/hrm integration ($20‑99/usuario/mes) + enterprise tiers.
- API de matching (por 1000 evaluaciones).
- Add‑ons de privacidad/compliance.

## CorpAIScan
- Suscripción por escaneo continuo (crawl + auditoría) $1‑5k/mes.
- Reportes bajo demanda + generación de bounties (rev‑share del gasto en tareas).
- Consultoría automatizada mínima (estándar de paquetes).
