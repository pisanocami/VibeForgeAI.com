# SkillSwap — Mars Shot Definition

## Problema a escala humana
Contratación de IA aplicada lenta, cara y riesgosa; devs sin ingresos estables.

## Propuesta 10x
Contratar outcomes con SLAs y acceptance tests; pagos automáticos; evidencias ejecutables.

## Network effects
Más bounties → más devs → mejores evals → mejor matching → más bounties.

## Loop central
Post bounty → Trial en sandbox → Evals → Pago → Feedback mejora matching.

## Métricas
Time‑to‑hire, success rate, ROI por bounty, retención de empresas.
