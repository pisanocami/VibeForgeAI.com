# CorpAIScan — Mars Value Proposition

## Valor
Transforma "queremos IA" en roadmap accionable y bounties con ROI y riesgos claros.

## Componentes
- Crawlers conformes + parsers
- Heurísticas/reglas de IA readiness
- Generación de reportes ejecutivos
- Export automático a SkillSwap (bounties)

## Métricas
% empresas que generan bounties, tiempo a primer bounty, ahorro estimado.
