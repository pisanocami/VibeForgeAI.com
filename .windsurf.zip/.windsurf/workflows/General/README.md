﻿# General

General purpose workflows

## Workflows in this category
- agent.md

