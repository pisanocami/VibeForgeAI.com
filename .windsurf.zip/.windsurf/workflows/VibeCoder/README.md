﻿# VibeCoder

Vibe-Coder specific workflows

## Workflows in this category
- vibe-coder-intelligence.md
 - vibe-coder-master.md
 - vibe-coder-rapid.md

